package com.example.eatwhat.controller;

import com.example.eatwhat.pojo.Article;
import com.example.eatwhat.pojo.PageBean;
import com.example.eatwhat.pojo.Result;
import com.example.eatwhat.service.ArticleService;
import com.example.eatwhat.utils.JwtUtil;
import jakarta.servlet.http.HttpServletResponse;
import org.apache.ibatis.annotations.Delete;
import org.apache.tomcat.util.net.openssl.ciphers.Authentication;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/article")
@CrossOrigin(origins = "*")
public class ArticleController {
    @Autowired
    private ArticleService articleService;
    @PostMapping
    public Result add(@RequestBody @Validated Article article){
        articleService.add(article);
        return  Result.success();
    }
    @GetMapping("/all")
    public Result<PageBean<Article>>all(
            Integer pageNum,
            Integer pageSize
    ){
        PageBean<Article> pb = articleService.all(pageNum,pageSize);
        return Result.success(pb);
    }
    @GetMapping
    public Result<PageBean<Article>>list(
            Integer pageNum,
            Integer pageSize
    ){
        PageBean<Article> pb = articleService.list(pageNum,pageSize);
        return Result.success(pb);
    }
    @PutMapping("/update")
    public Result update(@RequestBody Article article){
        articleService.update(article);
        return Result.success();
    }
    @DeleteMapping("/delete")
    public Result delete(Integer id){
        articleService.delete(id);
        return Result.success();
    }
}
