package com.example.eatwhat;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EatwhatApplication {

    public static void main(String[] args) {
        SpringApplication.run(EatwhatApplication.class, args);
    }

}
