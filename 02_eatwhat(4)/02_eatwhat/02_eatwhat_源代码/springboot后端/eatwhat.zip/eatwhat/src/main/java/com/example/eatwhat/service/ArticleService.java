package com.example.eatwhat.service;

import com.example.eatwhat.pojo.Article;
import com.example.eatwhat.pojo.PageBean;

public interface ArticleService {
    //新增文章
    void add(Article article);
    //分页列表查询
    PageBean<Article> list(Integer pageNum, Integer pageSize);
    //获取全部文章
    PageBean<Article> all(Integer pageNum, Integer pageSize);

    void update(Article article);

    void delete(Integer id);
}
